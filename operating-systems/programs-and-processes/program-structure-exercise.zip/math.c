int add(int a, int b) {
  return a + b;
}

int square(int n) {
  return n * n;
}