
int main(int argc, char*arvg[]) {
   printf("5 * 5 = %d\n", square(5));
}